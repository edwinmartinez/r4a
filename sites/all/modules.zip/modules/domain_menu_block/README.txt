README.txt for Domain Menu Block

Instuctions for use:

* Download and install the module.
* Go to /admin/structure/domain/domain_menu_block.
* Create menu block(s) for use.
* Confirm menu block(s) for each domain at domain/view/X/domain_menu_block.
* Assign the menu block(s) to your block settings at admin/structure/block.

TODO: Add documentation to drupal.org.

